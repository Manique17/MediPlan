package com.example.mediplan.data

data class User(
    val id: String,
    val name: String,
    val email: String
)