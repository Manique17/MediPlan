package com.example.mediplan.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons.Filled
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.mediplan.ui.theme.MediPlanTheme
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun AuthScreen(
    onLoginClick: (email: String, password: String) -> Unit,
    onRegisterClick: (name: String, email: String, password: String) -> Unit,
    onResetPasswordClick: (email: String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    var isLogin by remember { mutableStateOf(true) }
    var isResetPassword by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var surname by remember { mutableStateOf("") }
    var birthDate by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var confirmPasswordVisible by remember { mutableStateOf(false) }
    var resetEmail by remember { mutableStateOf("") }

    // Validation state
    var passwordsMatch by remember { mutableStateOf(true) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "MediPlan",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        Text(
            text = when {
                isResetPassword -> "Reset Password"
                isLogin -> "Login"
                else -> "Register"
            },
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        when {
            isResetPassword -> {
                // Reset password screen
                OutlinedTextField(
                    value = resetEmail,
                    onValueChange = { resetEmail = it },
                    label = { Text("Email") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Email,
                        imeAction = ImeAction.Done
                    )
                )

                Text(
                    text = "Enter your email address and we'll send you a link to reset your password.",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Button(
                    onClick = { onResetPasswordClick(resetEmail) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    enabled = resetEmail.isNotEmpty()
                ) {
                    Text("Send Reset Link")
                }

                TextButton(
                    onClick = {
                        isResetPassword = false
                        isLogin = true
                    },
                    modifier = Modifier.padding(vertical = 8.dp)
                ) {
                    Text("Back to Login")
                }
            }

            !isLogin -> {
                // Registration fields
                // Name field
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Next
                    )
                )

                // Surname field
                OutlinedTextField(
                    value = surname,
                    onValueChange = { surname = it },
                    label = { Text("Surname") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Next
                    )
                )

                // Birth date field with date picker
                var showDatePicker by remember { mutableStateOf(false) }
                val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                val calendar = remember { Calendar.getInstance() }

                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = birthDate,
                        onValueChange = { /* Read-only field, will be set by date picker */ },
                        label = { Text("Birth Date") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        readOnly = true
                    )

                    // Invisible clickable box over the text field
                    Box(
                        modifier = Modifier
                            .matchParentSize()
                            .clickable { showDatePicker = true }
                    )
                }

                if (showDatePicker) {
                    // Simple date picker dialog using stable components
                    Dialog(
                        onDismissRequest = { showDatePicker = false }
                    ) {
                        Surface(
                            shape = MaterialTheme.shapes.medium,
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp)
                            ) {
                                Text(
                                    text = "Select Birth Date",
                                    style = MaterialTheme.typography.titleLarge,
                                    modifier = Modifier.padding(bottom = 16.dp)
                                )

                                // Year, Month, Day selection
                                var selectedYear by remember { mutableStateOf(calendar.get(Calendar.YEAR)) }
                                var selectedMonth by remember { mutableStateOf(calendar.get(Calendar.MONTH)) }
                                var selectedDay by remember { mutableStateOf(calendar.get(Calendar.DAY_OF_MONTH)) }

                                // Year selection
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Year:",
                                        modifier = Modifier.width(80.dp)
                                    )

                                    val currentYear = Calendar.getInstance().get(Calendar.YEAR)
                                    val years = (currentYear downTo currentYear - 100).toList()

                                    var yearExpanded by remember { mutableStateOf(false) }

                                    Box {
                                        OutlinedTextField(
                                            value = selectedYear.toString(),
                                            onValueChange = {},
                                            readOnly = true,
                                            modifier = Modifier.fillMaxWidth(),
                                            trailingIcon = {
                                                IconButton(onClick = { yearExpanded = !yearExpanded }) {
                                                    Icon(
                                                        imageVector = Icons.Filled.DateRange,
                                                        contentDescription = "Select year"
                                                    )
                                                }
                                            }
                                        )

                                        DropdownMenu(
                                            expanded = yearExpanded,
                                            onDismissRequest = { yearExpanded = false },
                                            modifier = Modifier.fillMaxWidth(0.9f)
                                        ) {
                                            years.forEach { year ->
                                                DropdownMenuItem(
                                                    text = { Text(year.toString()) },
                                                    onClick = {
                                                        selectedYear = year
                                                        yearExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }

                                // Month selection
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Month:",
                                        modifier = Modifier.width(80.dp)
                                    )

                                    val months = listOf(
                                        "January", "February", "March", "April", "May", "June",
                                        "July", "August", "September", "October", "November", "December"
                                    )

                                    var monthExpanded by remember { mutableStateOf(false) }

                                    Box {
                                        OutlinedTextField(
                                            value = months[selectedMonth],
                                            onValueChange = {},
                                            readOnly = true,
                                            modifier = Modifier.fillMaxWidth(),
                                            trailingIcon = {
                                                IconButton(onClick = { monthExpanded = !monthExpanded }) {
                                                    Icon(
                                                        imageVector = Icons.Filled.DateRange,
                                                        contentDescription = "Select month"
                                                    )
                                                }
                                            }
                                        )

                                        DropdownMenu(
                                            expanded = monthExpanded,
                                            onDismissRequest = { monthExpanded = false },
                                            modifier = Modifier.fillMaxWidth(0.9f)
                                        ) {
                                            months.forEachIndexed { index, month ->
                                                DropdownMenuItem(
                                                    text = { Text(month) },
                                                    onClick = {
                                                        selectedMonth = index
                                                        monthExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }

                                // Day selection
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Day:",
                                        modifier = Modifier.width(80.dp)
                                    )

                                    // Calculate max days in the selected month
                                    val tempCalendar = Calendar.getInstance().apply {
                                        set(Calendar.YEAR, selectedYear)
                                        set(Calendar.MONTH, selectedMonth)
                                    }
                                    val maxDays = tempCalendar.getActualMaximum(Calendar.DAY_OF_MONTH)
                                    val days = (1..maxDays).toList()

                                    // Ensure selected day is valid for the month
                                    if (selectedDay > maxDays) {
                                        selectedDay = maxDays
                                    }

                                    var dayExpanded by remember { mutableStateOf(false) }

                                    Box {
                                        OutlinedTextField(
                                            value = selectedDay.toString(),
                                            onValueChange = {},
                                            readOnly = true,
                                            modifier = Modifier.fillMaxWidth(),
                                            trailingIcon = {
                                                IconButton(onClick = { dayExpanded = !dayExpanded }) {
                                                    Icon(
                                                        imageVector = Icons.Filled.DateRange,
                                                        contentDescription = "Select day"
                                                    )
                                                }
                                            }
                                        )

                                        DropdownMenu(
                                            expanded = dayExpanded,
                                            onDismissRequest = { dayExpanded = false },
                                            modifier = Modifier.fillMaxWidth(0.9f)
                                        ) {
                                            days.forEach { day ->
                                                DropdownMenuItem(
                                                    text = { Text(day.toString()) },
                                                    onClick = {
                                                        selectedDay = day
                                                        dayExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }

                                // Action buttons
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 16.dp),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    TextButton(
                                        onClick = { showDatePicker = false }
                                    ) {
                                        Text("Cancel")
                                    }

                                    Spacer(modifier = Modifier.width(8.dp))

                                    Button(
                                        onClick = {
                                            calendar.set(selectedYear, selectedMonth, selectedDay)
                                            birthDate = dateFormat.format(calendar.time)
                                            showDatePicker = false
                                        }
                                    ) {
                                        Text("OK")
                                    }
                                }
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Email,
                        imeAction = ImeAction.Next
                    )
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Next
                    ),
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                imageVector = if (passwordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                contentDescription = if (passwordVisible) "Hide password" else "Show password"
                            )
                        }
                    }
                )

                // Confirm password field
                OutlinedTextField(
                    value = confirmPassword,
                    onValueChange = {
                        confirmPassword = it
                        passwordsMatch = password == confirmPassword || confirmPassword.isEmpty()
                    },
                    label = { Text("Confirm Password") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    visualTransformation = if (confirmPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Done
                    ),
                    trailingIcon = {
                        IconButton(onClick = { confirmPasswordVisible = !confirmPasswordVisible }) {
                            Icon(
                                imageVector = if (confirmPasswordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                contentDescription = if (confirmPasswordVisible) "Hide password" else "Show password"
                            )
                        }
                    },
                    isError = !passwordsMatch
                )

                if (!passwordsMatch) {
                    Text(
                        text = "Passwords do not match",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(start = 16.dp)
                    )
                }
            }

            else -> {
                // Login fields
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Email,
                        imeAction = ImeAction.Next
                    )
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Done
                    ),
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                imageVector = if (passwordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                contentDescription = if (passwordVisible) "Hide password" else "Show password"
                            )
                        }
                    }
                )

                // Forgot password link
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = {
                            isResetPassword = true
                            resetEmail = email // Pre-fill with current email if available
                        }
                    ) {
                        Text("Forgot Password?")
                    }
                }
            }
        }

        if (!isResetPassword) {
            Button(
                onClick = {
                    if (isLogin) {
                        onLoginClick(email, password)
                    } else {
                        if (password == confirmPassword) {
                            onRegisterClick(name, email, password)
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                enabled = if (isLogin) {
                    email.isNotEmpty() && password.isNotEmpty()
                } else {
                    password == confirmPassword && name.isNotEmpty() && surname.isNotEmpty() &&
                    birthDate.isNotEmpty() && email.isNotEmpty() && password.isNotEmpty()
                }
            ) {
                Text(text = if (isLogin) "Login" else "Register")
            }

            TextButton(
                onClick = { isLogin = !isLogin },
                modifier = Modifier.padding(vertical = 8.dp)
            ) {
                Text(
                    text = if (isLogin) "Need an account? Register" else "Already have an account? Login"
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun AuthScreenPreview() {
    MediPlanTheme {
        AuthScreen(
            onLoginClick = { _, _ -> },
            onRegisterClick = { _, _, _ -> },
            onResetPasswordClick = { _ -> }
        )
    }
}