package com.example.mediplan

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.mediplan.data.AuthRepository
import com.example.mediplan.data.User
import com.example.mediplan.ui.screens.AuthScreen
import com.example.mediplan.ui.screens.HomeScreen
import com.example.mediplan.ui.theme.MediPlanTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    // Create an instance of the AuthRepository
    private val authRepository = AuthRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MediPlanTheme {
                MediPlanApp(
                    authRepository = authRepository,
                    onShowToast = { message ->
                        Toast.makeText(
                            this,
                            message,
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                )
            }
        }
    }
}

@Composable
fun MediPlanApp(
    authRepository: AuthRepository,
    onShowToast: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    // Track the current user
    var currentUser by remember { mutableStateOf<User?>(null) }

    // Observe the current user from the repository
    LaunchedEffect(authRepository) {
        authRepository.currentUser.collect { user ->
            currentUser = user
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        if (currentUser == null) {
            // Show login/register screen if not logged in
            AuthScreen(
                onLoginClick = { email, password ->
                    val success = authRepository.login(email, password)
                    val message = if (success) {
                        "Login successful"
                    } else {
                        "Login failed. Invalid credentials."
                    }
                    onShowToast(message)

                    scope.launch {
                        snackbarHostState.showSnackbar("Login attempted")
                    }
                },
                onRegisterClick = { name, email, password ->
                    val success = authRepository.register(name, email, password)
                    val message = if (success) {
                        "Registration successful"
                    } else {
                        "Registration failed. Email already in use."
                    }
                    onShowToast(message)

                    scope.launch {
                        snackbarHostState.showSnackbar("Registration attempted")
                    }
                },
                modifier = Modifier.padding(innerPadding)
            )
        } else {
            // Show home screen if logged in
            HomeScreen(
                onAddMedicationClick = {
                    onShowToast("Add Medication clicked")
                },
                onSeePlanClick = {
                    onShowToast("See Plan clicked")
                },
                onHistoryClick = {
                    onShowToast("History clicked")
                },
                onAccountClick = {
                    onShowToast("Account clicked")
                },
                onLogoutClick = {
                    authRepository.logout()
                    onShowToast("Logged out successfully")
                },
                userName = currentUser?.name ?: "",
                modifier = Modifier.padding(innerPadding)
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun AuthScreenPreview() {
    MediPlanTheme {
        MediPlanApp(
            authRepository = AuthRepository(),
            onShowToast = {}
        )
    }
}
