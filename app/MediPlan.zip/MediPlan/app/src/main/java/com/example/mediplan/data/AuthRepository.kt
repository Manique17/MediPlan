package com.example.mediplan.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

/**
 * A simple authentication repository for testing purposes.
 * In a real app, this would connect to a backend service.
 */
class AuthRepository {
    // Store the current user
    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    // In-memory storage of users (email -> User)
    private val users = mutableMapOf<String, UserCredentials>()

    // Add a test account
    init {
        // Create a test account
        val testEmail = "test@example.com"
        val testPassword = "password123"
        val testName = "Test User"
        
        users[testEmail] = UserCredentials(
            id = UUID.randomUUID().toString(),
            name = testName,
            email = testEmail,
            password = testPassword
        )
    }

    /**
     * Attempt to register a new user.
     * @return true if registration was successful, false if the email is already in use
     */
    fun register(name: String, email: String, password: String): Boolean {
        // Check if email is already registered
        if (users.containsKey(email)) {
            return false
        }

        // Create new user
        val newUser = UserCredentials(
            id = UUID.randomUUID().toString(),
            name = name,
            email = email,
            password = password
        )
        
        // Store user
        users[email] = newUser
        
        // Auto-login after registration
        _currentUser.value = User(newUser.id, newUser.name, newUser.email)
        
        return true
    }

    /**
     * Attempt to login a user.
     * @return true if login was successful, false if credentials are invalid
     */
    fun login(email: String, password: String): Boolean {
        val userCredentials = users[email] ?: return false
        
        // Check password
        if (userCredentials.password != password) {
            return false
        }
        
        // Set current user
        _currentUser.value = User(
            userCredentials.id,
            userCredentials.name,
            userCredentials.email
        )
        
        return true
    }

    /**
     * Logout the current user
     */
    fun logout() {
        _currentUser.value = null
    }

    /**
     * Private class to store user credentials
     */
    private data class UserCredentials(
        val id: String,
        val name: String,
        val email: String,
        val password: String
    )
}